Enrolment Scheme Master
Version as at 30/03/2016
Includes Special Temporary Enrolment Schemes in Chch

Edits in this version to:

March 2016:

709	Ormiston Junior College	AK	New Scheme
1513	Stanmore Bay School	AK	New Scheme
1280	Freyberg Community School	New Scheme
3703	Andersons Bay School	SI	New Scheme
3742	Grants Braes School	SI	New Scheme
3779	Musselburgh School	SI	New Scheme
3709	Balaclava School	SI	Ammended
1781	Knighton Normal School	HM	Ammended
2981	Riverlands School	SI	Ammended
2566	Gisborne Intermediate	NA	New Scheme
346	Darfield High School	SI	Ammended
347	Lincoln High School	SI	Ammended
1694	Bellevue School (Tauranga)	HM	New Scheme
1697	Bethlehem School	HM	Ammended

To remove

1577 	Woodhill School		AK	Abandoned
1449 	Pukekawa School 	AK	Abandoned
